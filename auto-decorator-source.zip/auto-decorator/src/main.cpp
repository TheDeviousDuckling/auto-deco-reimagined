#include <Geode/Geode.hpp>
#include <Geode/modify/EditorUI.hpp>
#include <random>
#include <vector>

using namespace geode::prelude;

// ---------------------------------------------------------------------------
//  THEMES
//  Each theme is just data: which object IDs to scatter, where, how big, and
//  which color channel to use. Tweak the IDs/channels to taste, then rebuild.
//  Color channels: 1000 BG, 1001 G1, 1002 Line, 1004 Obj, 1005 P1, 1006 P2,
//  1007 LBG, 1009 G2, 1010 Black, 1011 White.
// ---------------------------------------------------------------------------
struct Theme {
	const char* name;
	std::vector<int> topIDs;      // placed along the top edge of a block
	std::vector<int> bottomIDs;   // placed along the bottom edge
	std::vector<int> scatterIDs;  // floating pieces around the block
	int color;
	float minScale, maxScale;
	float perBlock;               // base pieces per block (multiplied by density)
	float rotJitter;              // random rotation in degrees (+/-)
	bool alignToEdge;             // top pieces upright, bottom pieces flipped
};

static const std::vector<Theme>& themes() {
	static const std::vector<Theme> t = {
		// Acheron: sharp, dark, glowing shards
		{ "Acheron",    {39, 8},  {39},    {1, 39}, 1005, 0.35f, 0.9f, 1.5f, 45.f,  true  },
		// Space: tiny "stars" and drifting debris
		{ "Space",      {},       {},      {1, 40}, 1011, 0.10f, 0.35f, 2.5f, 180.f, false },
		// Grasslands: small blades along the top
		{ "Grasslands", {39},     {},      {},      1004, 0.25f, 0.6f, 3.0f, 12.f,  true  },
		// Volcano: jagged spikes top and bottom
		{ "Volcano",    {8, 39},  {8, 39}, {1},     1005, 0.4f,  1.0f, 1.2f, 20.f,  true  },
		// Ocean: soft floating bubbles
		{ "Ocean",      {},       {39},    {1, 40}, 1006, 0.12f, 0.4f, 2.0f, 180.f, false },
		// Cyber: tidy small slabs
		{ "Cyber",      {40},     {40},    {1},     1005, 0.3f,  0.7f, 1.5f, 0.f,   true  },
		// Crystal: tilted shards
		{ "Crystal",    {8, 39},  {8},     {39},    1006, 0.3f,  0.8f, 1.3f, 35.f,  true  },
	};
	return t;
}

// ---------------------------------------------------------------------------
static std::mt19937& rng() {
	static std::mt19937 r{std::random_device{}()};
	return r;
}
static float rf(float a, float b) {
	return std::uniform_real_distribution<float>(a, b)(rng());
}
static int pick(std::vector<int> const& v) {
	return v[std::uniform_int_distribution<size_t>(0, v.size() - 1)(rng())];
}

static void spawn(LevelEditorLayer* lel, int id, CCPoint pos, float scale, float rot, int color) {
	auto* obj = lel->createObject(id, pos, true); // true = register for undo
	if (!obj) return;
	obj->updateCustomScaleX(scale);
	obj->updateCustomScaleY(scale);
	obj->setRotation(rot);
	if (obj->m_baseColor) obj->m_baseColor->m_colorID = color;
	if (obj->m_detailColor) obj->m_detailColor->m_colorID = color;
}

static void decorate(LevelEditorLayer* lel, std::vector<GameObject*> const& bases, Theme const& th, float density) {
	for (auto* base : bases) {
		CCPoint p = base->getPosition();
		CCSize s = base->getScaledContentSize();
		float halfW = s.width / 2.f, halfH = s.height / 2.f;

		int count = std::max(1, (int)std::round(th.perBlock * density));
		for (int i = 0; i < count; i++) {
			float sc = rf(th.minScale, th.maxScale);
			float x = p.x + rf(-halfW, halfW);

			// top edge
			if (!th.topIDs.empty()) {
				float rot = rf(-th.rotJitter, th.rotJitter);
				spawn(lel, pick(th.topIDs), {x, p.y + halfH + 15.f * sc}, sc, rot, th.color);
			}
			// bottom edge
			if (!th.bottomIDs.empty()) {
				float rot = (th.alignToEdge ? 180.f : 0.f) + rf(-th.rotJitter, th.rotJitter);
				spawn(lel, pick(th.bottomIDs), {x, p.y - halfH - 15.f * sc}, sc, rot, th.color);
			}
			// scatter
			if (!th.scatterIDs.empty()) {
				float ox = rf(-halfW - 45.f, halfW + 45.f);
				float oy = rf(-halfH - 60.f, halfH + 60.f);
				spawn(lel, pick(th.scatterIDs), {p.x + ox, p.y + oy}, sc, rf(0.f, 360.f), th.color);
			}
		}
	}
}

// ---------------------------------------------------------------------------
class $modify(AutoDecoUI, EditorUI) {
	struct Fields {
		size_t theme = 0;
		ButtonSprite* themeSpr = nullptr;
	};

	bool init(LevelEditorLayer* lel) {
		if (!EditorUI::init(lel)) return false;

		auto win = CCDirector::get()->getWinSize();
		auto menu = CCMenu::create();
		menu->setPosition({win.width - 70.f, 110.f});
		menu->setID("auto-decorator-menu"_spr);

		auto themeSpr = ButtonSprite::create(themes()[0].name, "goldFont.fnt", "GJ_button_04.png", 0.6f);
		m_fields->themeSpr = themeSpr;
		auto themeBtn = CCMenuItemSpriteExtra::create(themeSpr, this, menu_selector(AutoDecoUI::onTheme));
		themeBtn->setPosition({0.f, 22.f});

		auto goSpr = ButtonSprite::create("Decorate", "goldFont.fnt", "GJ_button_01.png", 0.6f);
		auto goBtn = CCMenuItemSpriteExtra::create(goSpr, this, menu_selector(AutoDecoUI::onDecorate));
		goBtn->setPosition({0.f, -22.f});

		menu->addChild(themeBtn);
		menu->addChild(goBtn);
		this->addChild(menu, 100);
		return true;
	}

	void onTheme(CCObject*) {
		auto& f = m_fields;
		f->theme = (f->theme + 1) % themes().size();
		f->themeSpr->setString(themes()[f->theme].name);
	}

	void onDecorate(CCObject*) {
		std::vector<GameObject*> bases;

		if (auto* sel = this->getSelectedObjectsOfCCArray()) {
			for (auto* o : CCArrayExt<GameObject*>(sel)) bases.push_back(o);
		}
		if (bases.empty() && Mod::get()->getSettingValue<bool>("decorate-all")) {
			for (auto* o : CCArrayExt<GameObject*>(m_editorLayer->m_objects)) bases.push_back(o);
		}
		if (bases.empty()) {
			FLAlertLayer::create("Auto Decorator", "Select some blocks first.", "OK")->show();
			return;
		}

		float density = (float)Mod::get()->getSettingValue<double>("density");
		auto const& th = themes()[m_fields->theme];
		decorate(m_editorLayer, bases, th, density);

		Notification::create(
			fmt::format("{} decoration added", th.name),
			NotificationIcon::Success
		)->show();
	}
};
