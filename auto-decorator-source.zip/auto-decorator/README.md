# Auto Decorator (Geode mod)

Select blocks in the editor, pick a theme (Acheron, Space, Grasslands, Volcano,
Ocean, Cyber, Crystal), press **Decorate**. Everything is undoable.

## Getting the .geode file
A .geode is a compiled package, so it has to be built with the Geode SDK:

**Easiest (no local setup):**
1. Create a new GitHub repo and upload these files.
2. Open the Actions tab -> "Build Binaries" -> Run workflow.
3. Download "Build Output" -> it contains `yourname.auto-decorator.geode`.
4. Drop it into your Geometry Dash `geode/mods` folder.

**Locally:** install Geode CLI + SDK, then `geode build`.

## Editing themes
Open `src/main.cpp` and edit the `themes()` table: object IDs, color channel,
scale range, density and rotation. Also change `id` and `developer` in `mod.json`.
